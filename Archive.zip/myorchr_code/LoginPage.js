/* =====================================================
Who                 When            Purpose
________________________________________________________
Yoseph Asir         07-Aug-2023     Initial
Rishi Priya V &
Nivarthi Raj G      08-Nov-2024     Implemented SystemAvailabilityMessage
====================================================== */
import React, { useState, useEffect } from 'react';
import { View, TextInput, Alert, Text, Modal, Dimensions, useWindowDimensions, TouchableOpacity, ActivityIndicator, Keyboard, TouchableWithoutFeedback, Image, ImageBackground, StyleSheet, Switch, Platform } from 'react-native';
import { JSEncrypt } from 'jsencrypt';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Admin from '../../assets/images/PNG/Admin.png';
import FaceID from '../../assets/images/PNG/FaceID.png';
import TouchID from '../../assets/images/PNG/TouchID.png';
import { APICallSyncforLogin, APICallSyncforAuthorize, APICallSyncForAnonymous, DtoBaseInModelSchema, APICallSyncForAnony, DtoBaseInModel, GetStoreVersion } from '../../Services/APIHandler';
import { InsMobileErrorBeforeLoginLog, InsMobileErrorLogVals, ValidateTextEncoded } from '../../Services/StringExtension';
import NetInfo from "@react-native-community/netinfo";
import * as Keychain from 'react-native-keychain';
import ReactNativeBiometrics, { BiometryTypes } from 'react-native-biometrics';
import getProviderMenuList from '../../Services/ProviderService';
import * as yup from 'yup';
import createCommonStyle from '../../assets/style/CommonStyleSheet';
import uuid from 'react-native-uuid';
import DeviceInfo from 'react-native-device-info';
import { Linking } from 'react-native';
import Analytics from 'appcenter-analytics';
import Config from 'react-native-config';
import { AlertFunction, ClearNotification } from '../Common/Common';
import AppVariables from '../Common/AppVariables';
import { Calendar } from 'react-native-calendars';
import HTML from 'react-native-render-html';
import { ACTIVE_API_URL } from '../../Services/APIHandler';
const Login = ({ route }) => {
    const CommonStyleSheet = createCommonStyle();
    const navigation = useNavigation();
    // State variables for managing user input and application state
    const [userName, setUserName] = useState('');
    const [password, setPassword] = useState('');
    const [hiddenPassword, setHiddenPassword] = useState('');
    const [passwordVisible, setPasswordVisible] = useState(false);
    const [enableUserID, setIsEnabledUserID] = useState(false);
    const [enableFaceID, setIsEnabledFaceID] = useState(false);
    const [biometricEnableToggle, setBiometricEnableToggle] = useState(true);
    const [isSectionVisible, setIsSectionVisible] = useState(true);
    const [isLoading, setIsLoading] = useState(false);
    const [userIDErrorMessage, setUserIDErrorMessage] = useState('');
    const [passwordErrorMessage, setPasswordErrorMessage] = useState('');
    const [modalErrorMessage, setModalErrorMessage] = useState(false);
    const [hasNetwork, setNetwork] = useState(false);
    const [biometricType, setBiometricType] = useState('LOGIN');
    const [biometricToggleType, setBiometricToggleType] = useState('');
    const [biometricImage, setBiometricImage] = useState(null);
    const [loginErrorMsg, setLoginErrorMsg] = useState('');
    const [systemMsg, setSystemMsg] = useState('');
    const { width } = useWindowDimensions();
    const [modalVisible, setModalVisible] = useState(false);
    // Initialize biometrics
    const biometrics = new ReactNativeBiometrics();
    // Local variables for managing state
    let keystoreUsername = '';
    let keystorePassword = '';
    let keyStoreFaceIDFlag = '';
    let setFaceIDFlag = '';
    let moreTab = '';
    let storeName = '';
    let needToHelp = false;
    let loginButton = false;
    let biometricSwitchGrid = false;
    let isUpdateAvailable = false;
    let hasLoggedOut = route.params?.hasLoggedOut == undefined ? true : route.params?.hasLoggedOut
    let updateHasLoggedIn = hasLoggedOut;
    let PWDSecureStorage = '';
    let passwordValidation = '';
    let userNameValidation = '';

    // useEffect hook to initialize app state and check for biometrics availability
    useEffect(() => {
        AppVariables.setVal('Timeout', 'N');
        InitializeComponent();
    }, []);
    // Initial setup function for the app
    const InitializeComponent = async () => {
        await Keychain.resetGenericPassword({ service: 'token_portSessionID' });
        biometrics.isSensorAvailable()
            .then(async (resultObject) => {
                const { available, biometryType } = resultObject
                if (available && biometryType === BiometryTypes.TouchID) {
                    setBiometricToggleType('Login with Touch ID®')

                } else if (available && biometryType === BiometryTypes.FaceID) {
                    setBiometricToggleType('Login with Face ID®')

                } else if (available && biometryType === BiometryTypes.Biometrics) {
                    setBiometricToggleType('Login with Fingerprint')
                }
                else {
                    setBiometricToggleType('Login')
                    setBiometricEnableToggle(false)
                }
            })
        await NetInfo.fetch().then(async state => {
            if (state.isConnected) {
                setNetwork(true);
                if (hasLoggedOut) {
                    await GetSystemAvailabilityMessage();
                }
                else {
                    await SetBiometricUI();
                }
            }
            else {
                setBiometricEnableToggle(false)
                Alert.alert("No Internet Connection", "Please check your internet connection and relaunch the app.",
                    [
                        { text: "OK" },
                        { text: "Retry", onPress: () => { InitializeComponent(), setBiometricEnableToggle(true) } }
                    ]);
            }
        });
    }
    const SetBiometricUI = async () => {
        await GetLatestVersionNumber();
        retrieveStoredUsernameAndFaceIDFlag();
        const unsubscribe = navigation.addListener('focus', async () => {
            retrieveStoredUsernameAndFaceIDFlag();
            const credentials = await Keychain.getGenericPassword({ service: "UserSensitiveInfo" });
            if (credentials == false) {
                setIsEnabledUserID(false);
            }
        });
        return unsubscribe;
    }
    const CloseModal = () => {
        setModalVisible(!modalVisible);
        SetBiometricUI();
    }
    const GetSystemAvailabilityMessage = async () => {
        try {
            setIsLoading(true);
            const responseGetSystemAvailabilityMessage = await APICallSyncForAnony('Login/GetSystemAvailabilityMessage');
            if (responseGetSystemAvailabilityMessage.status == 200) {
                if (responseGetSystemAvailabilityMessage.data.message.trim() !== null && responseGetSystemAvailabilityMessage.data.message.trim() !== "") {
                    setSystemMsg(responseGetSystemAvailabilityMessage.data.message);
                    setModalVisible(true);
                }
                else {
                    await SetBiometricUI();
                }
            }
            else {
                await SetBiometricUI();
            }
        }
        catch (ex) {
            await InsMobileErrorBeforeLoginLog('Login', 'GetSystemAvailabilityMessage', "StatusCode: " + ex?.status + " Error: " + ((ex?.errors != undefined) ? ex.errors : ex.message) + " Request: " + JSON.stringify((ex.value)));
            await SetBiometricUI();
        }
        finally {
            setIsLoading(false);
        }
    }

    // Function to check for the latest version of the app
    const GetLatestVersionNumber = async () => {
        try {
            const DtoGetVersionNumberInModel = {
                DeviceOS: (Platform.OS === "ios") ? 'iOS' : 'ANDROID'
            }
            const DtoGetVersionNumberSchema = yup.object().shape({
                DeviceOS: yup.string().max(60)
            });
            if (Platform.OS === "ios") {
                storeName = "the App Store";
            }
            else {
                storeName = "Google Play";
            }
            setIsLoading(true);
            const responseGetVersionNumber = await APICallSyncForAnonymous('CommonMobileApp/GetVersionNumber', DtoGetVersionNumberInModel, DtoGetVersionNumberSchema)
            if (responseGetVersionNumber.status === 200) {
                // setInitialLoadEmpty(false);
                await Keychain.setGenericPassword(responseGetVersionNumber.data.piiEncPublicKey, responseGetVersionNumber.data.piiEncPublicKey, { service: 'PII_ENC_PUBLIC_KEY' });
                await Keychain.setGenericPassword(responseGetVersionNumber.data.pwdPublicKey, responseGetVersionNumber.data.pwdPublicKey, { service: 'PWD_PUBLIC_KEY' });

                AppVariables.setVal('PII_ENC_PUBLIC_KEY', responseGetVersionNumber.data.piiEncPublicKey);
                AppVariables.setVal('PWD_PUBLIC_KEY', responseGetVersionNumber.data.pwdPublicKey);

                AppVariables.setVal("AppSettingsValues", responseGetVersionNumber.data);
                let appSequenceNum = await GetStoreVersion();
                const latestVersionInfo = responseGetVersionNumber.data;
                if (updateHasLoggedIn) {
                    if (appSequenceNum !== latestVersionInfo.latestStoreSequenceNumber) {
                        if (appSequenceNum < latestVersionInfo.latestStoreSequenceNumber) {
                            if (latestVersionInfo.mandateFlag === "Y") {
                                MandateUpdate();
                            } else {
                                const value = latestVersionInfo.latestStoreSequenceNumber - appSequenceNum;
                                if (value > 1) {
                                    MandateUpdate();
                                } else if (value === 1) {
                                    const update = await new Promise((resolve) => {
                                        isUpdateAvailable = true;
                                        Alert.alert(
                                            "App Update Available",
                                            "A new version of the app is available in " + storeName,
                                            [
                                                {
                                                    text: "Update App",
                                                    onPress: () => resolve(true)
                                                },
                                                {
                                                    text: "Skip",
                                                    onPress: () => {
                                                        isUpdateAvailable = false;
                                                        resolve(false);
                                                    },
                                                    style: "cancel"
                                                }
                                            ]
                                        );
                                    });
                                    if (update) {
                                        isUpdateAvailable = true;
                                        const url = (Platform.OS === "ios")
                                            ? "https://itunes.apple.com/us/app/myorchr/id1425991084"
                                            : "https://play.google.com/store/apps/details?id=com.orchr.MyORCHR";
                                        Linking.openURL(url);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else {
                await Alert.alert("Unable to check for updates", "Could not connect to " + storeName + " to check for updates. Please check your internet connection and try again.");
            }
        }
        catch (ex) {
            setIsLoading(false);
            await Alert.alert("Unable to check for updates", "Could not connect to " + storeName + " to check for updates. Please check your internet connection and try again.");
            await InsMobileErrorBeforeLoginLog('CommonMobileApp', 'GetMyVersionNumberNew', "StatusCode: " + ex?.status + " Error: " + ((ex?.errors != undefined) ? ex.errors : ex.message) + " Request: " + JSON.stringify((ex.value)));
        }
        finally {
            setIsLoading(false);
        }
    }
    const MandateUpdate = () => {
        isUpdateAvailable = true;
        Alert.alert(
            "App Update Available",
            "A new version of the app is available in " + storeName,
            [
                {
                    text: "Update App",
                    onPress: async () => {
                        biometricSwitchGrid = true;
                        loginButton = true;
                        needToHelp = true;
                        setBiometricImage(null);
                        if (Platform.OS === "ios") {
                            // Open App Store link for iOS
                            Linking.openURL("https://itunes.apple.com/us/app/myorchr/id1425991084");
                        } else {
                            // Open Play Store link for Android
                            Linking.openURL("https://play.google.com/store/apps/details?id=com.orchr.MyORCHR");
                        }
                    }
                }
            ]
        );
    }


    // Toggle FaceID functionality
    const ToggleFaceID_onValueChange = async () => {
        const FaceIDFlag = (enableFaceID === true) ? 'N' : 'Y';
        await Keychain.setGenericPassword(userName, FaceIDFlag, { service: 'SetFaceIDFlag' + userName });
        setIsEnabledFaceID(previousState => !previousState)
        if (!enableFaceID) {
            BiometricButtonValidation();
            await Keychain.setGenericPassword("true", "true", { service: 'AutoLoginFlag' });
            const credentials = await Keychain.getGenericPassword({ service: 'UsernameAutoLoginFlagPassword' })
            if (!passwordErrorMessage && !hasLoggedOut) {
                setPassword(credentials.password);
            }
        }
        else {
            await Keychain.setGenericPassword("false", "false", { service: 'AutoLoginFlag' });
            setPassword("");
            setBiometricType('LOGIN');
            setBiometricImage(null);
        }
    };
    // Validate biometric button availability
    const BiometricButtonValidation = () => {
        biometrics.isSensorAvailable()
            .then((resultObject) => {
                setIsEnabledUserID(true)
                const { available, biometryType } = resultObject
                if (available && biometryType === BiometryTypes.TouchID) {
                    setBiometricType("LOGIN WITH TOUCH ID®")
                    setBiometricImage(TouchID)
                } else if (available && biometryType === BiometryTypes.FaceID) {
                    setBiometricType('LOGIN WITH FACE ID®')
                    setBiometricImage(FaceID)
                } else if (available && biometryType === BiometryTypes.Biometrics) {
                    setBiometricImage(TouchID)
                    setBiometricType('LOGIN WITH FINGERPRINT')
                }
                else {
                    setBiometricType('LOGIN')
                    setBiometricEnableToggle(false)
                    setBiometricImage(null)
                }
            })
    };
    // Handle FaceID authentication
    const FaceIDAuthentication = async () => {
        try {
            passwordValidation = hiddenPassword || (password == "Empty" ? "" : password) || keystorePassword;
            userNameValidation = userName || keystoreUsername;
            if (!userNameValidation && !passwordValidation) {
                setUserIDErrorMessage('Please enter User ID.');
                setPasswordErrorMessage('Please enter Password.');
                return;
            }
            else if (userNameValidation && !passwordValidation) {
                setUserIDErrorMessage('');
                setPasswordErrorMessage('Please enter Password.');
                return;
            }
            else if (!userNameValidation && passwordValidation) {
                setPasswordErrorMessage('');
                setUserIDErrorMessage('Please enter User ID.');
                return;
            }
            const resultObject = await biometrics.simplePrompt({ promptMessage: 'Confirm fingerprint' });
            const { success } = resultObject;
            if (success) {
                setIsEnabledFaceID(true);
                Login_onPressed();
            }
            else {
                setBiometricType('LOGIN');
                setIsEnabledFaceID(false);
                await Keychain.setGenericPassword("false", "false", { service: 'AutoLoginFlag' });
                setPassword("");
                // await Keychain.resetGenericPassword({service: 'AutoLoginFlag'})
                setBiometricImage(null);
            }
        } catch (error) {
            setPassword("");
            setBiometricType('LOGIN');
            setIsEnabledFaceID(false);
            await Keychain.setGenericPassword("false", "false", { service: 'AutoLoginFlag' });
            setBiometricImage(null);
        }
    };
    // Toggle saving user ID functionality
    const ToggleSaveUserID_onValueChange = async () => {
        setIsEnabledUserID(previousState => !previousState)
        if (enableUserID == true) {
            setIsEnabledFaceID(false);
            setPassword("");
            setBiometricType('LOGIN')
            setBiometricImage(null)
            await Keychain.resetGenericPassword({ service: 'UsernameAutoLoginFlagPassword' })
            await Keychain.setGenericPassword("false", "false", { service: 'AutoLoginFlag' })
        }
    };
    // Retrieve stored username and FaceID flag from Keychain
    const retrieveStoredUsernameAndFaceIDFlag = async () => {
        try {
            const credentials = await Keychain.getGenericPassword({ service: 'UsernameAutoLoginFlagPassword' })
            if (credentials) {
                setIsEnabledUserID(true);
                const StoredUserNameAndFaceIDFlag = credentials.username;
                const setChangeUsername = StoredUserNameAndFaceIDFlag.slice(0, -1);
                keystoreUsername = (setChangeUsername);
                setUserName(keystoreUsername)
                const setFaceIDFlag = StoredUserNameAndFaceIDFlag.slice(-1);
                keyStoreFaceIDFlag = (setFaceIDFlag);
                await Keychain.setGenericPassword(keystoreUsername, keyStoreFaceIDFlag, { service: 'SetFaceIDFlag' + keystoreUsername });
                if (setFaceIDFlag === "Y") {
                    keystorePassword = (credentials.password)
                    setPassword(keystorePassword)
                    setIsEnabledFaceID(true);
                    const AutoLogin = await Keychain.getGenericPassword({ service: 'AutoLoginFlag' });
                    if (isUpdateAvailable == false) {
                        if (AutoLogin.username == "true" && hasLoggedOut == true) {
                            setIsSectionVisible(false);
                            BiometricButtonValidation();
                            await FaceIDAuthentication();
                            return;
                        }
                        else {
                            setIsSectionVisible(true);
                            BiometricButtonValidation();
                        }
                    }
                }
                else {
                    setIsEnabledFaceID(false)
                }
                if (setChangeUsername && credentials.password) {
                    setUserIDErrorMessage('');
                    setPasswordErrorMessage('');
                }
            }
        } catch (error) {
            AlertFunction("Error", error)
        }
    };
    // Generate a unique key for encryption
    async function GenerateKey() {
        let key = '';
        key = uuid.v4().replace(/-/g, ''); // Generate a UUID and remove dashes
        return key;
    };
    // Encrypt sensitive data using public key
    function PiiEncryption(keyvalue, publicKey) {
        if (keyvalue != null && publicKey != undefined) {
            var crypts = new JSEncrypt();
            crypts.setKey(publicKey);
            return crypts.encrypt(keyvalue);
        }
    }
    // Encrypt password using public key
    function PasswordEncryption(password, publicKey) {
        if (password != null && publicKey != undefined) {
            var crypt = new JSEncrypt();
            crypt.setKey(publicKey);
            return crypt.encrypt(password);
        }
    };
    const PasswordEye_onPress = () => {
        setPasswordVisible(!passwordVisible);
    };
    // Handle successful retrieval of two-factor authentication info
    const TFAInfoFound_Success = async () => {
        try {
            // ------------------------ Retrieve the credentials -------------------------   
            // const TFA_CookieToken = await Keychain.resetGenericPassword({service: 'myORCHR_trusted_device_' + AppVariables.getVal("UsernamePassword").Username.toUpperCase()});
            setIsLoading(true);
            const TFA_CookieToken = await Keychain.getGenericPassword({ service: 'myORCHR_trusted_device_' + AppVariables.getVal("UsernamePassword").Username.toUpperCase() });
            if (TFA_CookieToken != false && TFA_CookieToken != true) {
                const DtoTFAVerifyTrustDeviceSchema = DtoBaseInModelSchema.shape({
                    CookieTokenValue: yup.string().max(4000).nullable(),
                });
                const dtoTFAVerifyTrustDeviceInModel = {
                    CookieTokenValue: TFA_CookieToken.password
                }
                const responseVerifyTFATrustDevice = await APICallSyncforAuthorize('TFA/VerifyTFATrustDevice', dtoTFAVerifyTrustDeviceInModel, DtoTFAVerifyTrustDeviceSchema);
                if (responseVerifyTFATrustDevice.status == 200) {
                    if (responseVerifyTFATrustDevice.data.errorMessage === 'SUCCESS') {
                        await getProviderMenuList(navigation, "LOGIN");
                    }
                    else {
                        await Keychain.resetGenericPassword({ service: 'myORCHR_trusted_device_' + AppVariables.getVal("UsernamePassword").Username.toUpperCase() });
                        moreTab = true;
                        navigation.navigate('LoginSettings', { moreTab });
                    }
                }
                else {
                    await Keychain.resetGenericPassword({ service: 'myORCHR_trusted_device_' + AppVariables.getVal("UsernamePassword").Username.toUpperCase() });
                    moreTab = true;
                    navigation.navigate('LoginSettings', { moreTab });
                }
            }
            else {
                moreTab = true;
                await navigation.navigate('LoginSettings', { moreTab });
            }
            setPassword("");
            setUserName("");
            setHiddenPassword("");
            setIsLoading(false);
        }
        catch (ex) {
            await InsMobileErrorLogVals('TFA', 'VerifyTFATrustDevice', ex.toString())
            AlertFunction("Error", "Unable to retrieve trust this device information")
            await Keychain.resetGenericPassword({ service: 'myORCHR_trusted_device_' + AppVariables.getVal("UsernamePassword").Username.toUpperCase() });
            setIsLoading(false);
        }
    };

    // Handle login button press
    const Login_onPressed = async () => {
        // ------ Validation-----------//
        NetInfo.fetch().then(async state => {
            if (state.isConnected) {
                try {
                    userNameValidation = userName || keystoreUsername;
                    passwordValidation = hiddenPassword || (password == "Empty" ? "" : password) || keystorePassword;
                    if (!userNameValidation && !passwordValidation) {
                        setUserIDErrorMessage('Please enter User ID.');
                        setPasswordErrorMessage('Please enter Password.');
                        return;
                    }
                    else if (userNameValidation && !passwordValidation) {
                        setUserIDErrorMessage('');
                        setPasswordErrorMessage('Please enter Password.');
                        return;
                    }
                    else if (!userNameValidation && passwordValidation) {
                        setPasswordErrorMessage('');
                        setUserIDErrorMessage('Please enter User ID.');
                        return;
                    }
                    setIsLoading(true);
                    setUserIDErrorMessage('');
                    setPasswordErrorMessage('');
                    AppVariables.setVal('piiAppPublicKey', await GenerateKey());
                    const DtoLoginSchema = yup.object().shape({
                        Username: yup.string().max(40).required(),
                        Password: yup.string().max(172).required(),
                        BrowPubKey: yup.string().max(300).required()
                    });
                    AppVariables.setVal('EnableLogin', (passwordValidation));
                    const PasswordEncryptionKey = AppVariables.getVal('PWD_PUBLIC_KEY');
                    const AppPublicKey = AppVariables.getVal('PII_ENC_PUBLIC_KEY');
                    const [encryptionKey, appPubKey] = await Promise.all([
                        Keychain.getGenericPassword({ service: 'PWD_PUBLIC_KEY' }),
                        Keychain.getGenericPassword({ service: 'PII_ENC_PUBLIC_KEY' })
                    ]);
                    const effectiveEncryptionKey = encryptionKey.password || PasswordEncryptionKey;
                    const effectiveAppPubKey = appPubKey.password || AppPublicKey;
                    //----------Input class for API call------------//           
                    const DtoLoginInModel = {
                        Username: (await ValidateTextEncoded(userNameValidation, 'Username')),
                        Password: PasswordEncryption((await ValidateTextEncoded(passwordValidation, 'Password')), effectiveEncryptionKey),
                        BrowPubKey: PiiEncryption(AppVariables.getVal('piiAppPublicKey'), effectiveAppPubKey)
                    }
                    AppVariables.setVal("UsernamePassword", DtoLoginInModel);
                    // -------------To maintain the Password in Keychain----------/

                    // -------------To maintain the Keychain with FaceID and Fingerprint Flag.----------//         
                    let setDeviceFaceIDFlag;
                    if (enableFaceID == true || keystorePassword) {
                        PWDSecureStorage = passwordValidation;
                        setDeviceFaceIDFlag = await Keychain.getGenericPassword({ service: 'SetFaceIDFlag' + userNameValidation });
                    }
                    else {
                        setDeviceFaceIDFlag = false;
                        PWDSecureStorage = "Empty";
                    }
                    const DeviceFaceIDFlag = {
                        isDeviceFaceIDFlag: (setDeviceFaceIDFlag === false) ? "N" : setDeviceFaceIDFlag.password,
                    }
                    //----Web API call ---------//
                    const responseLogin = await APICallSyncforLogin('Login/Login', DtoLoginInModel, DtoLoginSchema)
                    if (responseLogin.status == 200) {
                        // -------------------------------- output class ---------------------------------------// 
                        if (responseLogin.data.message == 'SUCCESS') {
                            AppVariables.setVal('ipAddress', responseLogin.data.ipAddress);
                            // To maintain the username, FaceIDFlag, and password, we store them in the Keychain.
                            if (enableUserID == true || keyStoreFaceIDFlag === 'Y') {
                                await Keychain.setGenericPassword(AppVariables.getVal("UsernamePassword").Username + DeviceFaceIDFlag.isDeviceFaceIDFlag, PWDSecureStorage, { service: "UserSensitiveInfo" });
                                Keychain.setGenericPassword(AppVariables.getVal("UsernamePassword").Username + DeviceFaceIDFlag.isDeviceFaceIDFlag, PWDSecureStorage, { service: 'UsernameAutoLoginFlagPassword' })
                            }
                            else {
                                await Keychain.resetGenericPassword({ service: "UserSensitiveInfo" });
                            }
                            AppVariables.setVal('piiAPIPublicKey', responseLogin.data.apiPubKey);
                            // ------------------------ The Token and PortSessionID stored in keychain. -------------------------
                            Keychain.setGenericPassword(responseLogin.data.token, responseLogin.data.portSessionID, { service: 'token_portSessionID' })
                            if (responseLogin.data.tfaInfoFound === "N") {
                                moreTab = true;
                                setLoginErrorMsg('')
                                await navigation.navigate('LoginSettings', { moreTab });
                                Analytics.trackEvent('Logged in');
                                ClearNotification();
                                setPassword("");
                                setHiddenPassword("");
                                setUserName("");
                                setIsLoading(false);
                            }
                            else if (responseLogin.data.tfaInfoFound === 'Y') {
                                Analytics.trackEvent('Logged in');
                                ClearNotification();
                                setLoginErrorMsg('');
                                TFAInfoFound_Success();
                            }
                            else {
                                setIsLoading(false);
                                AlertFunction("Error", "Could not login, please try again.")
                            }
                        }
                        else {
                            setLoginErrorMsg(responseLogin.data.message);
                            setIsLoading(false);
                            setBiometricType('LOGIN');
                            setBiometricImage(null);
                            setUserName("");
                            setPassword("");
                            setHiddenPassword("");
                            setIsEnabledUserID(false);
                            setIsEnabledFaceID(false);
                            await Keychain.resetGenericPassword({ service: 'UsernameAutoLoginFlagPassword' });
                            await Keychain.setGenericPassword("false", "false", { service: 'AutoLoginFlag' });
                        }
                    }
                    else {
                        setIsLoading(false);
                        setModalErrorMessage(true);
                    }
                }
                catch (ex) {
                    setIsLoading(false);
                    setModalErrorMessage(true);
                    await InsMobileErrorBeforeLoginLog('Login', 'Login', "StatusCode: " + ex?.status + " Error: " + ((ex?.errors != undefined) ? ex.errors : ex.message) + " Request: " + ex?.config?.data);
                }
            }
            else {
                setIsLoading(false);
                Alert.alert("No Internet Connection", "Please check your internet connection and relaunch the app.",
                    [
                        { text: "OK" }
                    ]);
            }
        });
    };
    const handleOutsidePress = () => {
        Keyboard.dismiss()
    };
    return (
        <TouchableWithoutFeedback onPress={handleOutsidePress} accessible={true}>
            <View style={styles.container}>
                <ImageBackground style={styles.backgroundImage} source={require('../../assets/images/PNG/LoginBackground.jpg')} >
                    <View style={{ flex: 1, justifyContent: 'center' }}>
                        <View style={{ alignItems: 'center', justifyContent: 'center' }}>
                            <Image style={{ width: 160, resizeMode: 'contain', alignItems: 'center' }} source={require('../../assets/images/PNG/OrchrLogo.png')}>
                            </Image>
                        </View>
                        <View style={{ marginHorizontal: Dimensions.get('window').width > 768 ? 100 : 40 }}>
                            <View style={{ flexDirection: "row", }}>
                                <TextInput
                                    style={[styles.inputBox, { height: 40, width: '100%', position: 'relative', marginTop: 12, paddingLeft: 35, padding: 10, color: "#000" }]}
                                    placeholderTextColor="#575757"
                                    placeholder="User ID"
                                    editable={hasNetwork}
                                    value={userName}
                                    onChangeText={(text) => setUserName(text.trim())}
                                />
                                <Icon name='person' style={{ alignSelf: 'center', color: '#575757', paddingTop: 11, paddingLeft: 5, position: 'absolute', }} size={25} />
                            </View>
                            <Text style={styles.errorMessage} >{userIDErrorMessage}</Text>
                            <View style={{ flexDirection: "row", }}>
                                <TextInput
                                    style={[styles.inputBox, { height: 40, width: '100%', position: 'relative', marginTop: 3, paddingLeft: 35, paddingRight: 40, padding: 10, color: "#000" }]}
                                    placeholderTextColor="#575757"
                                    placeholder="Password"
                                    editable={hasNetwork}
                                    value={hiddenPassword}
                                    contextMenuHidden={true}
                                    keyboardType={passwordVisible ? 'visible-password' : 'default'}
                                    secureTextEntry={!passwordVisible}
                                    onChangeText={(value) => { setPassword(value), setHiddenPassword(value) }}
                                    autoCorrect={false}
                                    autoComplete='off'
                                    spellCheck={false}
                                    importantForAutofill='no'
                                />
                                <Icon name='lock' style={{ alignSelf: 'center', color: '#575757', paddingTop: 5, paddingLeft: 9, position: 'absolute', }} size={20} />
                                <TouchableOpacity onPress={PasswordEye_onPress} style={{ position: 'absolute', right: 0, bottom: 0, justifyContent: 'center', alignSelf: 'center', width: 35, alignItems: 'center', borderBottomRightRadius: 6, borderTopRightRadius: 6, height: 40 }} >
                                    <Icon name={passwordVisible ? 'visibility' : 'visibility-off'} size={22} color="#575757" />
                                </TouchableOpacity>
                            </View>
                            <Text style={styles.errorMessage} >{passwordErrorMessage}</Text>
                            {isSectionVisible && (
                                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                                    <View style={{ flexDirection: 'row', marginBottom: 15, marginTop: 10, width: '50%' }}>
                                        <Switch
                                            disabled={!hasNetwork || biometricSwitchGrid}
                                            value={enableUserID}
                                            style={{ transform: [{ scaleX: .9 }, { scaleY: .9 }] }}
                                            thumbColor={enableUserID ? 'white' : '#f4f3f4'}
                                            trackColor={{ false: '#767577', true: '#189a04' }}
                                            checked={enableUserID}
                                            onPress={() => setIsEnabledUserID(!enableUserID)}
                                            onValueChange={ToggleSaveUserID_onValueChange}>
                                        </Switch>
                                         <Text
                                            style={{
                                                flex: 1,
                                                flexWrap: 'wrap',
                                                alignSelf: 'center',
                                                color: '#000',
                                                marginLeft:
                                                    Platform.OS === 'ios' && parseFloat(Platform.Version) >= 26
                                                        ? 15
                                                        : Platform.OS === 'android' ? 0: 5,
                                            }}
                                        >
                                            Save User ID
                                        </Text>
                                    </View>
                                    {biometricEnableToggle ?
                                        <View style={{ flexDirection: 'row', marginBottom: 15, marginTop: 10, width: '50%' }}>
                                            <Switch
                                                value={enableFaceID}
                                                disabled={!hasNetwork || biometricSwitchGrid}
                                                style={{ transform: [{ scaleX: .9 }, { scaleY: .9 }] }}
                                                thumbColor={enableFaceID ? 'white' : '#f4f3f4'}
                                                trackColor={{ false: '#767577', true: '#189a04' }}
                                                onValueChange={ToggleFaceID_onValueChange}>
                                            </Switch>
                                            <Text style={{ flex: 1, flexWrap: 'wrap', alignSelf: 'center', color: '#000', marginLeft: Platform.OS === 'android' ? 0 : 10 }} >{biometricToggleType}</Text>
                                        </View>
                                        : null
                                    }
                                </View>
                            )}
                            <TouchableOpacity disabled={!hasNetwork || loginButton} onPress={enableFaceID ? FaceIDAuthentication : Login_onPressed} style={[styles.appButtonContainer, { marginTop: 10 }]}>
                                <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
                                    {biometricImage &&
                                        <View >
                                            <Image style={{ width: 30, height: 30, marginRight: 10 }} source={biometricImage} />
                                        </View>
                                    }
                                    <Text style={styles.appButtonText}>{biometricType}</Text>
                                </View>
                            </TouchableOpacity>
                            <Text style={[styles.errorMessage, { textAlign: 'center', marginTop: 20 }]} >{loginErrorMsg}</Text>
                            {ACTIVE_API_URL != "PRODUCTION" &&
                                <Text style={{ color: "red", textAlign: "center" }}>{ACTIVE_API_URL}</Text>
                            }
                            <View style={{ alignItems: 'center', justifyContent: 'center', marginTop: 10 }}>
                                <Image style={{ width: 100, height: 60, resizeMode: 'contain' }} source={require('../../assets/images/PNG/EbenLogo.png')}>
                                </Image>
                                <Text style={{ fontSize: 12, color: '#000' }}>Preferred Partner</Text>
                            </View>
                            <View style={{ alignItems: 'center', justifyContent: 'center', paddingTop: 25 }}>
                                <Text
                                    style={{ color: '#2b66fc' }} disabled={!hasNetwork || needToHelp}
                                    onPress={() => navigation.navigate('ForgotCredentialsPage')}>Need Help?</Text>
                            </View>
                        </View>
                    </View>
                    {/* Please contact administrator modal alert */}
                    <Modal
                        animationType="fade"
                        transparent={true}
                        visible={modalErrorMessage}
                        onRequestClose={() => {
                            setModalErrorMessage(!modalErrorMessage);
                        }}>
                        <View style={CommonStyleSheet.modalViewTransparent}>
                            <View style={styles.modalView}>
                                <View style={{ alignItems: 'center', justifyContent: 'center', height: 110 }}>
                                    <Image style={{ width: 140, resizeMode: 'contain', alignItems: 'center' }} source={Admin}>
                                    </Image>
                                </View>
                                <Text style={styles.modalText}>Problem in Login. Please contact administrator.</Text>
                                <TouchableOpacity
                                    style={[styles.button, styles.buttonClose]}
                                    onPress={() => setModalErrorMessage(!modalErrorMessage)}>
                                    <Text style={styles.textStyle}>Close</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    </Modal>
                    {systemMsg !== '' &&
                        <Modal
                            animationType="fade"
                            transparent={true}
                            visible={modalVisible}>
                            <View style={CommonStyleSheet.modalViewTransparent}>
                                <View style={{ margin: 20, padding: 20, backgroundColor: '#fff', borderRadius: 8 }}>
                                    <View style={{ rowGap: 10 }}>
                                        <Text style={[CommonStyleSheet.dataLabel, { textAlign: 'center' }]}>Message</Text>
                                        <HTML contentWidth={width} source={{
                                            html: `<div style="color: red;"><span><b>${systemMsg}</b></span></div>`
                                        }} />
                                    </View>
                                    <View style={{ alignItems: 'center', marginTop: 10 }}>
                                        <TouchableOpacity style={[CommonStyleSheet.btnPrimary, { width: 60 }]} onPress={() => CloseModal()}>
                                            <Text style={CommonStyleSheet.btnAlign}>OK</Text>
                                        </TouchableOpacity>
                                    </View>
                                </View>
                            </View>
                        </Modal>
                    }
                    <Calendar style={{ display: 'none' }} />
                </ImageBackground>
                {isLoading && (
                    <View style={[CommonStyleSheet.loadingContainer, { marginTop: 0 }]}>
                        <ActivityIndicator size="large" color="#fff" />
                    </View>
                )}
                <Text style={{ color: "#000000", fontSize: 12, textAlign: 'center', position: 'absolute', bottom: 35, right: 0, left: 0 }}>App Version: {DeviceInfo.getVersion()}</Text>
            </View>
        </TouchableWithoutFeedback>
    );
};
const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    backgroundImage: {
        flex: 1,
        height: '100%'
    },
    inputBox: {
        borderWidth: 1,
        borderColor: "#7c7c7ca2",
        borderRadius: 6,
        justifyContent: "center",
        alignItems: "center",
    },
    appButtonContainer: {
        backgroundColor: "#2b66fc",
        borderRadius: 6,
        paddingVertical: 10,
        height: 45,
        width: '100%',
        justifyContent: 'center'
    },
    appButtonText: {
        fontSize: 15,
        color: "#fff",
        alignSelf: "center",
        fontWeight: '600',
        alignItems: 'center'
    },
    errorMessage: {
        paddingVertical: 0,
        fontSize: 12,
        color: 'red',
        minHeight: 17,
        marginTop: 2
    },
    modalView: {
        width: 300,
        margin: 20,
        backgroundColor: 'white',
        borderRadius: 20,
        padding: 35,
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: {
            width: 3,
            height: 5,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 10,
    },
    buttonClose: {
        backgroundColor: '#ff3734',
        paddingHorizontal: 20,
        borderRadius: 20,
        padding: 10,
        elevation: 2,
    },
    textStyle: {
        color: 'white',
        fontWeight: 'bold',
        textAlign: 'center',
    },
    modalText: {
        marginBottom: 15,
        marginTop: 25,
        fontSize: 14,
        fontWeight: '500',
        textAlign: 'center',
        color: '#000'
    },
});
export default Login;

