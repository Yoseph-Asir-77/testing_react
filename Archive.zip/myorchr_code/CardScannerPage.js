
/* =====================================================
Who                 When            Purpose
________________________________________________________
Yoseph Asir         27-Nov-2023     Initial
====================================================== */
import React, { useEffect, useState, useRef } from "react";
import { Image, TouchableOpacity, useColorScheme, SafeAreaView, Animated, Platform, View, Modal, ActivityIndicator, Text, StyleSheet, ImageBackground, ScrollView, Alert } from "react-native";
import DocumentScanner from "react-native-document-scanner-plugin";
import BackgroundImage from "../../assets/images/PNG/Background.jpg";
import createCommonStyle from '../../assets/style/CommonStyleSheet';
import Delete from "../../assets/images/PNG/Delete.png";
import Edit from "../../assets/images/PNG/Edit.png";
import ShareIcon from "../../assets/images/PNG/Share.png";
import { APICallSyncforAuthorize, DtoBaseInModelSchema } from '../../Services/APIHandler';
import { InsMobileErrorLogVals, ValidateTextEncoded } from '../../Services/StringExtension';
import { AlertFunction, CameraPermissionRequest } from "../Common/Common";
import { TextField as TextEntry } from 'rn-material-ui-textfield';
import * as yup from 'yup';
import ViewShot, { captureRef } from 'react-native-view-shot';
import Share from 'react-native-share';
import RNFS from 'react-native-fs';
import * as Progress from 'react-native-progress';
import ImageResizer from '@bam.tech/react-native-image-resizer';
import AppVariables from "../Common/AppVariables";

export default ({ navigation, route }) => {
  const CommonStyleSheet = createCommonStyle();
  const progress = useRef(new Animated.Value(0)).current;
  const [isImageLoading, setIsImageLoading] = useState(false);
  const [progressValue, setProgressValue] = useState(0);
  const { item, cardListEdit } = route.params;
  const [isLoading, setIsLoading] = useState(false);
  const [cardDataLoader, setCardDataLoader] = useState(false);
  const [scannedFrontImage, setScannedFrontImage] = useState();
  const [scannedBackImage, setScannedBackImage] = useState();
  const [DescriptionText, setDescriptionText] = useState(null);
  const [editValue, setEditValue] = useState(false);
  const [editHide, setEditHide] = useState(false);
  const [emptyCardButton, setEmptyCardButton] = useState();
  const [modalVisibleBackImage, setModalVisibleBackImage] = useState(false);
  const [modalVisibleFrontImage, setModalVisibleFrontImage] = useState(false);
  const [APIFrontImage, setAPIFrontImage] = useState();
  const [APIBackImage, setAPIBackImage] = useState();
  const [cardErrorMgs, SetCardErrorMgs] = useState('');
  const [crdEditableFlag, setCrdEditableFlag] = useState(false);
  const isDarkMode = useColorScheme() === 'dark';
  const scannerImageDetails = AppVariables.getVal("AppSettingsValues");
  const ref = useRef();
  let permissionStatus = '';

  useEffect(() => {
    if (isImageLoading) {
      const value = AppVariables.getVal("AppSettingsValues").attachmentUploadLoadTime; // total duration in seconds
      const duration = value * 1000; // convert to ms
      const steps = 100;
      const intervalTime = duration / steps; // ms per tick
      const increment = 1 / steps;

      const interval = setInterval(() => {
        setProgressValue((prev) => {
          const newValue = prev + increment;
          if (newValue >= 1) {
            clearInterval(interval);
            return 1;
          }
          return newValue;
        });
      }, intervalTime);

      return () => clearInterval(interval);
    }
    InitializeComponent();
  }, [navigation, isImageLoading]);

  useEffect(() => {
    if (isImageLoading) {
      Animated.timing(progress, {
        toValue: progressValue,
        duration: 200,
        useNativeDriver: false,
      }).start();
    }
  }, [progressValue, isImageLoading]);

  const interpolatedProgress = progress.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 1],
  });
  const progressPercentage = Math.round(progressValue * 100);

  const ResetProgress = () => {
    setIsImageLoading(false);
    setProgressValue(0);
    progress.setValue(0);
  };

  const InitializeComponent = async () => {
    setEditValue(cardListEdit)
    setEmptyCardButton(cardListEdit)
    setDescriptionText(item.cardsDesc)
    setCrdEditableFlag(item.isCrdEditable == "Y" ? true : false)
    if (cardListEdit == false) {
      GetEmpCardDetails();
    }
  }

  const scanImage = async (setImage) => {
    permissionStatus = await CameraPermissionRequest()
    if (permissionStatus === 'granted') {
      const { scannedImages } = await DocumentScanner.scanDocument({
        maxNumDocuments: 1,
        // responseType: ResponseType.Base64,
        croppedImageQuality: 10,
      });

      if (scannedImages.length > 0) {

        try {
          const stats = await RNFS.stat(scannedImages[0]);
          if (stats.size === 0) {
            Alert.alert('Error', 'Uploaded image is corrupted. Please try again.', [
              {
                text: "OK",
              },
            ]);
          } else {
            if ((stats.size > scannerImageDetails.uploadImageFileByteSize) && (scannerImageDetails.imageCompressionFlag == "Y")) {
              const compressionRatioValue = await GetCompressionRatio(stats.size);
              const resizedImageUri = await ResizeImage(scannedImages[0], compressionRatioValue)
              await ReadFileAsBase64(resizedImageUri, setImage);
            } else {
              await ReadFileAsBase64(scannedImages[0], setImage);
            }

          }
        } catch (error) {
          Alert.alert('Error', error.toString() + 'Uploaded image is corrupted. Please try again.', [
            {
              text: "OK",
            },
          ]);
        }
      }
    }
    else if (permissionStatus === 'denied') {
      AlertFunction("Allow access", "Please allow the app to access the camera in settings");
    }
    else {
      AlertFunction("Camera Access Unavailable", "Verify that MyORCHR is allowed to access camera in the Settings app");
    }
  };
  const scanFrontImage = async () => {
    scanImage(setScannedFrontImage);
  };
  const scanBackImage = async () => {
    scanImage(setScannedBackImage);
  };
  const GetCompressionRatio = async (fileSize) => {
    return (scannerImageDetails.uploadImageFileByteSize / fileSize) * 100;
  };
  const ResizeImage = async (uri, quality) => {
    {
      try {
        // Wrap Image.getSize in a Promise to make it compatible with async/await
        const GetImageDimensions = (uri) => {
          return new Promise((resolve, reject) => {
            Image.getSize(
              uri,
              (width, height) => resolve({ width, height }),
              (error) => reject(error)
            );
          });
        };
        // Get image dimensions
        const { width, height } = await GetImageDimensions(uri);

        // Resize the image
        const resizedImage = await ImageResizer.createResizedImage(
          uri,
          width, // new width (can be adjusted based on requirements)
          height, // new height (can be adjusted based on requirements)
          'JPEG', // format
          quality // quality
        );

        // Return the resized image URI
        return resizedImage.uri;

      } catch (err) {
        throw err; // Re-throw the error to handle it higher up the call chain if needed
      }
    }
  };
  const ReadFileAsBase64 = async (uri, setImage) => {
    RNFS.readFile(uri, 'base64')
      .then((base64Data) => {
        setImage(base64Data);
        setEditValue(true);
        setEditHide(true)
      })
      .catch((error) => {
        Alert.alert("Error", "Could not upload card", [
          {
            text: "OK",
          },
        ]);
      });
  };

  const GetEmpCardDetails = async () => {
    try {
      setIsLoading(true);
      const DtoGetMyCardsImageInModel = {
        DigIDCardTxnID: item.digIDCardTxnID,
      }
      const DtoGetMyCardsImageSchema = DtoBaseInModelSchema.shape({
        DigIDCardTxnID: yup.string().max(32).required(),
      });
      const responseGetMyCardsImage = await APICallSyncforAuthorize("Cards/GetMyCardsImage", DtoGetMyCardsImageInModel, DtoGetMyCardsImageSchema)
      if (responseGetMyCardsImage.status == 200) {
        setScannedFrontImage(responseGetMyCardsImage.data.idCardFront);
        setScannedBackImage(responseGetMyCardsImage.data.idCardBack);
        setAPIFrontImage(responseGetMyCardsImage.data.idCardFront);
        setAPIBackImage(responseGetMyCardsImage.data.idCardBack);
        setCardDataLoader(true)
      }
      else {
        AlertFunction('Error', "Could not load card details", navigation, "CardsPage");
      }
      setIsLoading(false);
    }
    catch (ex) {
      AlertFunction('Error', "Could not load card details", navigation, "CardsPage");
      await InsMobileErrorLogVals('Cards', 'GetMyCardsImage', "StatusCode: " + ex?.status + " Error: " + ((ex?.errors != undefined) ? ex.errors : ex.message) + " Request: " + JSON.stringify((ex.value)));
    }
  }
  const InsertUpdateDelete = async (sender, mode) => {
    try {
      if (!sender || !DescriptionText || !scannedFrontImage) {
        if (!DescriptionText) {
          SetCardErrorMgs('Please enter description.');
          return;
        }
        else if (!scannedFrontImage) {
          SetCardErrorMgs('');
          Alert.alert("Image Required", "Please capture the front image of the card", [{ text: "OK" }]);
          return;
        }
      }
      SetCardErrorMgs('');
      if (mode == 'DELETE') {
        setIsLoading(true);
      }
      else {
        setIsImageLoading(true);
      }
      const DtoSaveImageReceiverInModel = {
        DigIDCardTxnID: sender,
        CardTxnDesc: await ValidateTextEncoded(DescriptionText, 'CardTxnDesc'),
        FrontImg: scannedFrontImage,
        BackImg: scannedBackImage,
        PlnTypeID: "",
        Mode: mode,
        PlnID: "",
        FromSource: await ValidateTextEncoded("MYORCHR", 'FromSource'),
      }
      const DtoSaveImageReceiverSchema = DtoBaseInModelSchema.shape({
        DigIDCardTxnID: yup.string().max(32).nullable(),
        CardTxnDesc: yup.string().max(255).nullable(),
        PlnTypeID: yup.string().max(32).nullable(),
        Mode: yup.string().max(12).nullable(),
        PlnID: yup.string().max(32).nullable(),
        FromSource: yup.string().max(10).nullable(),
        FrontImg: yup.string().nullable(),
        BackImg: yup.string().nullable(),
      });
      const responseMngSaveImageReceiver = await APICallSyncforAuthorize('Cards/MngSaveImageReceiver', DtoSaveImageReceiverInModel, DtoSaveImageReceiverSchema)
      if (responseMngSaveImageReceiver.status == 200) {
        if (mode == "DELETE") {
          AlertFunction('Message', "Your card has been successfully deleted.", navigation, "CardsPage");
        }
        else if (mode == "UPDATE") {
          AlertFunction('Message', "Your card has been successfully updated.", navigation, "CardsPage");
        }
        else {
          AlertFunction('Message', "Your card has been successfully uploaded.", navigation, "CardsPage");
        }
      }
      else {
        setIsLoading(false);
        setIsImageLoading(false);
        if (responseMngSaveImageReceiver.status == 406 && responseMngSaveImageReceiver.data) {
          Alert.alert("Alert", responseMngSaveImageReceiver.data.toString().replace(/"/g, ''), [
            {
              text: "OK",
            },
          ]);
        } else {
          Alert.alert("Error", "Could not save card image. Please try again.", [
            {
              text: "OK", onPress: () => { navigation.pop(); }
            },
          ]);
        }
      }
    }
    catch (ex) {
      AlertFunction('Error', "Could not save card image", navigation, "CardsPage");
      await InsMobileErrorLogVals('Cards', 'MngSaveImageReceiver', "StatusCode: " + ex?.status + " Error: " + ((ex?.errors != undefined) ? ex.errors : ex.message) + " Request: " + JSON.stringify((ex.value)));
    }
    finally {
      ResetProgress();
      setIsLoading(false);
    }
  }

  const CardSubmit_onPress = () => {
    if (!cardListEdit) {
      if (editHide) {
        const mode = (APIFrontImage == scannedFrontImage && APIBackImage == scannedBackImage) ? "UPDATE_DESC" : "UPDATE";
        const sender = item.digIDCardTxnID;
        InsertUpdateDelete(sender, mode);
      }
    }
    else {
      const mode = "INSERT";
      const sender = "";
      InsertUpdateDelete(sender, mode)
    }
  }
  const Edit_onPress = () => {
    setScannedFrontImage(scannedFrontImage)
    setScannedBackImage(scannedBackImage)
    setEditValue(true);
    setEditHide(true)
  }
  const Delete_onPress = () => {
    Alert.alert("Delete Card",
      "Are you sure you want to delete this card?", [
      { text: 'No' },
      {
        text: 'Yes', onPress: () => {
          const sender = item.digIDCardTxnID;
          const mode = "DELETE"
          InsertUpdateDelete(sender, mode)
        }
      },
    ]
    )
  }

  const CardCancel = () => {
    Alert.alert("Confirmation", "Are you sure you want go back? Changes will not be saved.", [
      { text: 'No' },
      {
        text: 'Yes', onPress: () => {
          navigation.pop()
        }
      },
    ]
    )
  }
  const saveImage = async () => {
    try {
      const uri = await captureRef(ref, {
        format: 'png',
        quality: 0.7,
      });
      await Share.open({ url: uri });
    }
    catch (error) { }
  };

  return (
    <SafeAreaView style={CommonStyleSheet.container} >
      <View style={CommonStyleSheet.scrollViewContainer} >
        <ScrollView style={{ marginBottom: Platform.OS === 'android' ? 0 : 65 }} keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
          {!isImageLoading &&
            <View style={[CommonStyleSheet.container, { padding: Platform.OS === 'android' ? 0 : 15 }]}>
              <View >
                {editValue &&
                  <Text style={[styles.info, { marginBottom: editHide ? 0 : 15 }]}>
                    You may capture images of 1 or 2 sided cards. If your card has only
                    1 side, capture image then scroll down and click SAVE.
                  </Text>
                }
                <View>
                  {(!editValue || editHide) &&
                    <View>
                      {cardDataLoader &&
                        <View>
                          {crdEditableFlag &&
                            <View style={{ flexDirection: 'row', justifyContent: 'flex-end', gap: 18, marginTop: 15, marginBottom: 5 }}>
                              {!editHide &&
                                <TouchableOpacity onPress={Edit_onPress}>
                                  <Image source={Edit} />
                                </TouchableOpacity>
                              }
                              {(!editHide || editHide) &&
                                <TouchableOpacity onPress={Delete_onPress}>
                                  <Image source={Delete} />
                                </TouchableOpacity>
                              }
                            </View>
                          }
                        </View>
                      }
                    </View>
                  }
                  {editValue ?
                    <View style={[styles.cardDes, { marginTop: editHide ? 8 : 0 }]}>
                      <TextEntry
                        textColor='#000'
                        label={'Card description'}
                        value={DescriptionText}
                        onChangeText={setDescriptionText}
                        tintColor={'gray'}
                        labelTextStyle={{ color: "rgb(144,144,144)", fontSize: 15, marginLeft: "33%" }}
                        maxLength={50}
                        selectionColor={{ color: "rgb(144,144,144)" }}
                        lineWidth={1}
                        activeLineWidth={1}
                        fontSize={14}
                        inputContainerStyle={{ paddingLeft: 3 }}

                      />
                      <Text style={CommonStyleSheet.errorMsg}>{cardErrorMgs}</Text>
                    </View>
                    :
                    <View>
                      {cardDataLoader &&
                        <View style={[CommonStyleSheet.card, { alignItems: 'center', marginBottom: 5 }]}>
                          <Text style={styles.dis_title}>Description</Text>
                          <Text style={styles.dis_quotes}>{item.cardsDesc}</Text>
                        </View>
                      }
                    </View>
                  }
                </View>
                {(cardDataLoader || emptyCardButton) &&
                  <View>
                    {!scannedFrontImage ?
                      <View>
                        <TouchableOpacity style={styles.cardView} onPress={scanFrontImage}>
                          <Text style={styles.cardText}>Scan Front Image</Text>
                        </TouchableOpacity>
                      </View>
                      :
                      <View>
                        {(scannedFrontImage || !editValue || editHide) && (
                          <View>
                            {!editHide ?
                              <View>
                                <Modal
                                  animationType="fade"
                                  transparent={true}
                                  visible={modalVisibleFrontImage}
                                  onRequestClose={() => {

                                    setModalVisibleFrontImage(!modalVisibleFrontImage);
                                  }}>
                                  <View style={[styles.cardModelView, { backgroundColor: isDarkMode ? "#000" : "#fff" }]}>
                                    <ViewShot ref={ref} style={styles.cardShort}>
                                      <Image source={{ uri: `data:image/png;base64,${scannedFrontImage}` }} style={[styles.image, { height: 200 }]} />
                                    </ViewShot>
                                    <View style={styles.shareIconPosition}>
                                      <TouchableOpacity
                                        onPress={saveImage}>
                                        <Image style={styles.shareIcon} tintColor={isDarkMode ? "#fff" : "#000"} source={ShareIcon} />
                                      </TouchableOpacity>
                                    </View>
                                    <TouchableOpacity
                                      style={[CommonStyleSheet.btnPrimary, { position: 'absolute', bottom: 50, right: 30, borderRadius: 50 }]}
                                      onPress={() => setModalVisibleFrontImage(!modalVisibleFrontImage)}>
                                      <Text style={[CommonStyleSheet.btnAlign, { fontSize: 14 }]} >Close</Text>
                                    </TouchableOpacity>
                                  </View>
                                </Modal>
                                <TouchableOpacity
                                  onPress={() => setModalVisibleFrontImage(true)}>
                                  <Image source={{ uri: `data:image/png;base64,${scannedFrontImage}` }} style={styles.image} />
                                </TouchableOpacity>
                              </View>
                              :
                              <TouchableOpacity style={styles.cardView} onPress={scanFrontImage}>
                                <Image source={{ uri: `data:image/png;base64,${scannedFrontImage}` }} style={styles.image} />
                              </TouchableOpacity>
                            }
                          </View>
                        )}
                      </View>
                    }
                    {!scannedBackImage ?
                      <View>
                        {(!scannedBackImage == null || editValue) &&
                          <View>
                            <TouchableOpacity style={styles.cardView} onPress={scanBackImage}>
                              <Text style={styles.cardText}>Scan Back Image</Text>
                            </TouchableOpacity>
                          </View>
                        }
                      </View>
                      :
                      <View>
                        {(scannedBackImage || !editValue || editHide) && (
                          <View>
                            {!editHide ?
                              <View>
                                <Modal
                                  animationType="fade"
                                  transparent={true}
                                  visible={modalVisibleBackImage}
                                  onRequestClose={() => {
                                    setModalVisibleBackImage(!modalVisibleBackImage);
                                  }}>
                                  <View style={[styles.cardModelView, { backgroundColor: isDarkMode ? "#000" : "#fff" }]}>
                                    <ViewShot ref={ref}
                                      style={styles.cardShort}
                                    >
                                      <Image source={{ uri: `data:image/png;base64,${scannedBackImage}` }} style={[styles.image, { height: 200 }]} />
                                    </ViewShot>

                                    <View style={styles.shareIconPosition}>
                                      <TouchableOpacity
                                        onPress={saveImage}>
                                        <Image style={styles.shareIcon} tintColor={isDarkMode ? "#fff" : "#000"} source={ShareIcon} />
                                      </TouchableOpacity>
                                    </View>

                                    <View style={{ position: 'absolute', bottom: 50, right: 30, flexDirection: 'row', gap: 10 }}>
                                      <TouchableOpacity
                                        style={[CommonStyleSheet.btnPrimary, { borderRadius: 50 }]}
                                        onPress={() => setModalVisibleBackImage(!modalVisibleBackImage)}>
                                        <Text style={[CommonStyleSheet.btnAlign, { fontSize: 14 }]} >Close</Text>
                                      </TouchableOpacity>
                                    </View>
                                  </View>
                                </Modal>
                                <TouchableOpacity
                                  onPress={() => setModalVisibleBackImage(true)}>
                                  <Image source={{ uri: `data:image/png;base64,${scannedBackImage}` }} style={styles.image} />
                                </TouchableOpacity>
                              </View>
                              :
                              <TouchableOpacity style={styles.cardView} onPress={scanBackImage}>
                                <Image source={{ uri: `data:image/png;base64,${scannedBackImage}` }} style={styles.image} />
                              </TouchableOpacity>
                            }
                          </View>
                        )}
                      </View>
                    }
                  </View>
                }
                {editValue &&
                  <View style={styles.btnColumn}>
                    <TouchableOpacity style={[CommonStyleSheet.btnPrimary, { width: 80 }]} onPress={CardSubmit_onPress} >
                      <Text style={CommonStyleSheet.btnAlign}>Save</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[CommonStyleSheet.btnGray, { width: 80 }]} onPress={CardCancel}>
                      <Text style={CommonStyleSheet.btnAlign}>Cancel</Text>
                    </TouchableOpacity>
                  </View>
                }
              </View>
            </View>
          }
        </ScrollView>
      </View>
      {isImageLoading && (
        <View style={CommonStyleSheet.loadingContainerAfter}>
          <View style={styles.progressContainer}>
            <Progress.Circle progress={interpolatedProgress} size={70} indeterminate={true} />
            <View style={styles.progressTextContainer}>
              <Text style={styles.progressText}>{progressPercentage}%</Text>
            </View>
          </View>
          <Text style={{ color: 'white' }}>Upload in progress. Please wait...</Text>
        </View>
      )}
      {isLoading && (
        <View style={CommonStyleSheet.loadingContainerAfter}>
          <ActivityIndicator size="large" color="#fff" />
        </View>
      )}
      <ImageBackground
        style={CommonStyleSheet.imageBackground}
        source={BackgroundImage}
      />

    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  backgroundImage: {
    height: "100%",
  },
  info: {
    color: "red",
    fontSize: 14,
  },
  shareIcon: {
    width: 30,
    height: 30
  },
  cardDes: {
    backgroundColor: "#fff",
    height: 80,
    justifyContent: "flex-end",
    padding: 10,
    paddingBottom: 5,
    borderRadius: 8,
    marginBottom: 5,
  },
  image: {
    width: "100%",
    minHeight: 190,
    marginVertical: 10,
    borderColor: "#fcf094",
    borderRadius: 8,
    borderWidth: 3,
    marginVertical: 5,
    objectFit: "fill",
  },
  cardView: {
    width: "100%",
    height: 185,
    marginVertical: 10,
    backgroundColor: "#6198ef",
    borderRadius: 8,
    marginVertical: 5,
    justifyContent: "center",
    shadowColor: "#000",
    shadowOpacity: 0.2,
    shadowRadius: 5,
    shadowOffset: { width: 0, height: 0 },
  },
  cardText: {
    textAlign: "center",
    color: "#fff",
    fontSize: 18,
    fontWeight: "500",
  },
  input: {
    borderColor: "#ddd",
    paddingVertical: 10,
    fontSize: 18,
    borderBottomWidth: 1,
  },
  btnColumn: {
    flexDirection: "row",
    justifyContent: "center",
    gap: 10,
    marginTop: 10,
  },
  dis_title: {
    fontSize: 15,
    color: '#000'
  },
  dis_quotes: {
    fontWeight: "500",
    fontSize: 14,
    color: "#000000",
    paddingTop: 2,
  },
  cardModelView: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 6,
    position: 'absolute',
    height: '100%',
    width: '100%'
  },
  cardShort: {
    width: '100%',
    height: 'auto',
    padding: 20,
    shadowColor: "#000000d4",
    shadowOpacity: 0.5,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 0 },
  },
  shareIconPosition: {
    position: 'absolute',
    top: 80,
    right: 30,
    flexDirection: 'row',
    gap: 10
  },
  progressContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  progressTextContainer: {
    position: 'absolute',
    justifyContent: 'center',
    alignItems: 'center',
  },
  progressText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600'
  },
});